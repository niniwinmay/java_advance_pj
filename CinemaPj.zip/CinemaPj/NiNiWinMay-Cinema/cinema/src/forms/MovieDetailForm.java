package forms;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JRadioButton;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

import entities.*;
import services.*;

public class MovieDetailForm {

	private JFrame frame;
	private JTable tblMovie;
	private ActorService actorService;
	private MovieService movieService;
	private ActressService actressService;
	private MovieTypeService movieTypeService;
	private DirectorService directorService;
	private DefaultTableModel dtm = new DefaultTableModel();
	private List<Movie> movieList = new ArrayList<>();
	private List<Movie> filteredMovieList = new ArrayList<>();
	Movie movie;
	private Director director;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MovieDetailForm window = new MovieDetailForm();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MovieDetailForm() {
		initialize();
		this.movieService = new MovieService();
		setTableDesign();
		uploadData(Optional.empty());
	}
	
	public void setTableDesign() {
		dtm.addColumn("ID");
		dtm.addColumn("Movie Name");
		dtm.addColumn("Director");
		dtm.addColumn("Actor");
		dtm.addColumn("Actress");
		dtm.addColumn("Movie Type");
		dtm.addColumn("Duration");
		
		this.tblMovie.setModel(dtm);
	}
	
	private void uploadData(Optional<List<Movie>> optionalMovie) {

		this.dtm = (DefaultTableModel) this.tblMovie.getModel();
		this.dtm.getDataVector().removeAllElements();
		this.dtm.fireTableDataChanged();

		this.movieList = this.movieService.findAllMovie();
		this.filteredMovieList = optionalMovie.orElseGet(() -> this.movieList).stream().collect(Collectors.toList());

		filteredMovieList.forEach(e -> {
			Object[] row = new Object[7];
			row[0] = e.getMovie_id();
			row[1] = e.getMovie_name();
			row[2] = e.getDirector().getDirector_name();
			row[3] = e.getActor().getActor_name();
			row[4] = e.getActress().getActress_name();
			row[5] = e.getMovieType().getMovieType_name();
			row[6] = e.getDuration();
			
			dtm.addRow(row);
		});

		this.tblMovie.setModel(dtm);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JRadioButton rboDirector = new JRadioButton("Director");
		rboDirector.setFont(new Font("Tahoma", Font.BOLD, 12));
		rboDirector.setBounds(26, 35, 104, 21);
		frame.getContentPane().add(rboDirector);
		
		JRadioButton rboActor = new JRadioButton("Actor");
		rboActor.setFont(new Font("Tahoma", Font.BOLD, 12));
		rboActor.setBounds(136, 35, 77, 21);
		frame.getContentPane().add(rboActor);
		
		JRadioButton rdbtnActress = new JRadioButton("Actress");
		rdbtnActress.setFont(new Font("Tahoma", Font.BOLD, 12));
		rdbtnActress.setBounds(217, 35, 77, 21);
		frame.getContentPane().add(rdbtnActress);
		
		JRadioButton rboActor_1_1 = new JRadioButton("Movie Type");
		rboActor_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		rboActor_1_1.setBounds(136, 72, 119, 21);
		frame.getContentPane().add(rboActor_1_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(26, 114, 546, 258);
		frame.getContentPane().add(scrollPane);
		
		tblMovie = new JTable();
		scrollPane.setViewportView(tblMovie);
		this.tblMovie.setFocusable(false);
		this.tblMovie.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent me) {
				if(me.getClickCount()==1) {
					String id = tblMovie.getValueAt(tblMovie.getSelectedRow(), 0).toString();

					movie = movieService.findMovieById(id);
					MovieCreateForm movieCreate=new MovieCreateForm(movie);
					movieCreate.frameMovieCreate.setVisible(true);
					movieCreate.btnCreate.setText("Edit");
					movieCreate.frameMovieCreate.setTitle("Movie Edit Form");
					movieCreate.panel.setBorder(new TitledBorder(null, "Editing Movie", TitledBorder.LEADING, TitledBorder.TOP, null, null));
				}
			}
		});

		
		JComboBox cboSearch = new JComboBox();
		cboSearch.setBounds(297, 35, 119, 21);
		frame.getContentPane().add(cboSearch);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setBounds(325, 72, 91, 21);
		frame.getContentPane().add(btnSearch);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Searching", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(26, 10, 422, 95);
		frame.getContentPane().add(panel);
		
		JButton btnShow = new JButton("Show All");
		btnShow.setBounds(481, 83, 91, 21);
		frame.getContentPane().add(btnShow);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBounds(481, 382, 91, 21);
		frame.getContentPane().add(btnBack);
	}
}
