package forms;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import entities.Actress;
import services.ActressService;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.border.EtchedBorder;
import java.awt.Color;

public class ActressForm {

	private JFrame frame;
	private JTextField txtName;
	private JTable tblActress;
	private ActressService actressService;
	private DefaultTableModel dtm = new DefaultTableModel();
	private List<Actress> actressList = new ArrayList<>();
	private List<Actress> filteredActressList = new ArrayList<>();
	private Actress actress;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ActressForm window = new ActressForm();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public ActressForm() {
		
		initialize();
		setTableDesign();
		this.actressService=new ActressService();
		uploadData(Optional.empty());
	}

	private void setTableDesign() {
		dtm.addColumn("ID");
		dtm.addColumn("Name");
		this.tblActress.setModel(dtm);
	}
	
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 14));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Actress Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(20, 37, 107, 31);
		frame.getContentPane().add(lblNewLabel);
		
		txtName = new JTextField();
		txtName.setBounds(137, 42, 107, 24);
		frame.getContentPane().add(txtName);
		txtName.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 102, 358, 148);
		frame.getContentPane().add(scrollPane);
		
		JButton btnSave = new JButton("Create");
		btnSave.setBounds(265, 43, 89, 23);
		frame.getContentPane().add(btnSave);
		
		tblActress = new JTable();
		scrollPane.setViewportView(tblActress);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				actress=null;
				txtName.setText("");
				btnSave.setText("Create");
			}
		});
		btnCancel.setBounds(265, 68, 89, 23);
		frame.getContentPane().add(btnCancel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Create New Actress", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(10, 11, 358, 85);
		frame.getContentPane().add(panel);
		this.tblActress.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
			if (!tblActress.getSelectionModel().isSelectionEmpty()) {

				String id = tblActress.getValueAt(tblActress.getSelectedRow(), 0).toString();

				actress = actressService.findActressById(id);

				txtName.setText(actress.getActress_name());
				btnSave.setText("Edit");
			}
		});
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			     if (null != actress && actress.getActress_id() != 0) {

			    	 	actress.setActress_name(txtName.getText());

	                    if (!actress.getActress_name().isBlank()) {

	                        actressService.updateActress(String.valueOf(actress.getActress_id()), actress);
	                        txtName.setText("");
	                        actress=null;
	                        uploadData(Optional.empty());
	                        btnSave.setText("Create");
	                    } else {
	                        JOptionPane.showMessageDialog(null, "Check Required Field");
	                    }
	                } else {
	                	if (txtName.getText().matches(".*[0-9].*")) {
	    					JOptionPane.showMessageDialog(null, "Name must be String");
	    				} else if (!txtName.getText().isBlank()) {

	    					Actress actress = new Actress();
	    					actress.setActress_name(txtName.getText());
	    					actressService.createActress(actress);
	    					uploadData(Optional.empty());
	    					txtName.setText("");
	    				} else {
	    					JOptionPane.showMessageDialog(null, "Enter RequiredField");
	    				}
	                }
			}
		});
	}
	
	private void uploadData(Optional<List<Actress>> optionalActress) {

		 this.dtm = (DefaultTableModel) this.tblActress.getModel();
		 this.dtm.getDataVector().removeAllElements();
		 this.dtm.fireTableDataChanged();

		this.actressList = this.actressService.findAllActress();
		this.filteredActressList = optionalActress.orElseGet(() ->
									this.actressList).stream()
									.collect(Collectors.toList());

		filteredActressList.forEach(e -> {
			Object[] row = new Object[2];
			row[0] = e.getActress_id();
			row[1] = e.getActress_name();
			dtm.addRow(row);
		});

		this.tblActress.setModel(dtm);
	}
}
