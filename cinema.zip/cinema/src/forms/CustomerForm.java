package forms;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

import config.DBConfig;
import entities.Customer;
import services.CustomerService;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class CustomerForm {

	public JFrame frameCustomerRecordForm;
	private JTextField txtName;
	private JTextField txtPhone;
	private JTextField txtEmail;
	private JTextField txtAddress;
	private JTable tblCustomer;
	private Customer customer;
	private CustomerService customerService;
	private DefaultTableModel dtm = new DefaultTableModel();
	private final DBConfig dbConfig = new DBConfig();
	private List<Customer> customerList = new ArrayList();
	private List<Customer> filterCustomerList = new ArrayList();
	private JTextField txtSearch;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustomerForm window = new CustomerForm();
					window.frameCustomerRecordForm.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * 
	 * @throws SQLException
	 * @wbp.parser.entryPoint
	 */
	public CustomerForm() throws SQLException {
		initialize();
		this.initializeDependency();
		this.setTableDesign();
		this.loadAllCustomers(Optional.empty());
	}

	private void initializeDependency() {
			this.customerService = new CustomerService();
	}

	private void setTableDesign() {
		dtm.addColumn("ID");
		dtm.addColumn("Name");
		dtm.addColumn("Phone Number");
		dtm.addColumn("Email");
		dtm.addColumn("Address");
		this.tblCustomer.setModel(dtm);
	}

	private void loadAllCustomers(Optional<List<Customer>> optionalCustomer) {
		this.dtm = (DefaultTableModel) this.tblCustomer.getModel();
		this.dtm.getDataVector().removeAllElements();
		this.dtm.fireTableDataChanged();

		this.customerList = this.customerService.findAllCustomers();

		this.filterCustomerList = optionalCustomer.orElseGet(() -> this.customerList).stream().collect(Collectors.toList());

		filterCustomerList.forEach(e -> {
			Object[] row = new Object[5];
			row[0] = e.getCustomer_id();
			row[1] = e.getCustomer_name();
			row[2] = e.getCustomer_phone();
			row[3] = e.getCustomer_email();
			row[4] = e.getCustomer_address();
			dtm.addRow(row);
		});

		this.tblCustomer.setModel(dtm);
	}

	private void resetFormData() {
		txtName.setText("");
		txtPhone.setText("");
		txtEmail.setText("");
		txtAddress.setText("");
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frameCustomerRecordForm = new JFrame();
		frameCustomerRecordForm.setResizable(false);
		frameCustomerRecordForm.getContentPane().setBackground(SystemColor.inactiveCaptionBorder);
		frameCustomerRecordForm.setTitle("Customer Record Form");
		frameCustomerRecordForm.setBounds(100, 100, 600, 515);
		frameCustomerRecordForm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameCustomerRecordForm.getContentPane().setLayout(null);

		JLabel lblName = new JLabel("Name");
		lblName.setHorizontalAlignment(SwingConstants.LEFT);
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblName.setBounds(36, 32, 74, 29);
		frameCustomerRecordForm.getContentPane().add(lblName);

		txtName = new JTextField();
		txtName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtName.setColumns(10);
		txtName.setBounds(114, 32, 193, 29);
		frameCustomerRecordForm.getContentPane().add(txtName);

		JLabel lblPhone = new JLabel("Phone No.");
		lblPhone.setHorizontalAlignment(SwingConstants.LEFT);
		lblPhone.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblPhone.setBounds(36, 71, 74, 29);
		frameCustomerRecordForm.getContentPane().add(lblPhone);

		txtPhone = new JTextField();
		txtPhone.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtPhone.setColumns(10);
		txtPhone.setBounds(114, 71, 193, 29);
		frameCustomerRecordForm.getContentPane().add(txtPhone);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 200, 549, 203);
		frameCustomerRecordForm.getContentPane().add(scrollPane);

	

		JLabel lblAddress = new JLabel("Address");
		lblAddress.setHorizontalAlignment(SwingConstants.LEFT);
		lblAddress.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblAddress.setBounds(36, 149, 85, 29);
		frameCustomerRecordForm.getContentPane().add(lblAddress);

		txtAddress = new JTextField();
		txtAddress.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtAddress.setColumns(10);
		txtAddress.setBounds(114, 149, 193, 29);
		frameCustomerRecordForm.getContentPane().add(txtAddress);

		JLabel lblEmail = new JLabel("Email");
		lblEmail.setHorizontalAlignment(SwingConstants.LEFT);
		lblEmail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblEmail.setBounds(36, 110, 74, 29);
		frameCustomerRecordForm.getContentPane().add(lblEmail);

		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtEmail.setColumns(10);
		txtEmail.setBounds(114, 110, 193, 29);
		frameCustomerRecordForm.getContentPane().add(txtEmail);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			     if (null != customer && customer.getCustomer_id() != 0) {

			    		customer.setCustomer_name(txtName.getText());
    					customer.setCustomer_phone(txtPhone.getText());
    					customer.setCustomer_email(txtEmail.getText());
    					customer.setCustomer_address(txtAddress.getText());

	                    if (!customer.getCustomer_name().isBlank() && !customer.getCustomer_phone().isBlank() && !customer.getCustomer_email().isBlank() && !customer.getCustomer_address().isBlank()) {

	                        customerService.updateCustomer(String.valueOf(customer.getCustomer_id()), customer);
	                        resetFormData();
	                        customer=null;
	                        loadAllCustomers(Optional.empty());
	                        btnSave.setText("Create");
	                    } else {
	                        JOptionPane.showMessageDialog(null, "Check Required Field");
	                    }
	                } else {
	                	customer = new Customer();
    					customer.setCustomer_name(txtName.getText());
    					customer.setCustomer_phone(txtPhone.getText());
    					customer.setCustomer_email(txtEmail.getText());
    					customer.setCustomer_address(txtAddress.getText());
	                	if (txtName.getText().matches(".*[0-9].*")) {
	    					JOptionPane.showMessageDialog(null, "Name must be String");
	    				} else if (!customer.getCustomer_name().isBlank() && !customer.getCustomer_phone().isBlank() && !customer.getCustomer_email().isBlank() && !customer.getCustomer_address().isBlank()) {
	    					customerService.createCustomer(customer);
	    					JOptionPane.showMessageDialog(null, "Save Successfully!!!");
	    					resetFormData();
	    					loadAllCustomers(Optional.empty());
	    				} else {
	    					JOptionPane.showMessageDialog(null, "Enter RequiredField");
	    				}
	                }
			}
		});
		btnSave.setBounds(329, 56, 91, 26);
		frameCustomerRecordForm.getContentPane().add(btnSave);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setBounds(199, 426, 91, 26);
		frameCustomerRecordForm.getContentPane().add(btnSearch);
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String search = txtSearch.getText();

				loadAllCustomers(Optional.of(customerList.stream()
						.filter(customer -> (customer.getCustomer_name().toLowerCase().startsWith(search.toLowerCase())) ||(customer.getCustomer_phone().equals(search)))
						.collect(Collectors.toList())));
			}
		});
		
		tblCustomer = new JTable();
		tblCustomer.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scrollPane.setViewportView(tblCustomer);
		this.tblCustomer.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
			if (!tblCustomer.getSelectionModel().isSelectionEmpty()) {
				String id = tblCustomer.getValueAt(tblCustomer.getSelectedRow(), 0).toString();

				customer = customerService.findCustomerId(id);
				// System.out.println(employee);

				txtName.setText(customer.getCustomer_name());
				txtPhone.setText(customer.getCustomer_phone());
				txtEmail.setText(customer.getCustomer_email());
				txtAddress.setText(customer.getCustomer_address());
				btnSave.setText("Edit");

			}
		});
		
		txtSearch = new JTextField();
		txtSearch.setBounds(25, 424, 162, 31);
		frameCustomerRecordForm.getContentPane().add(txtSearch);
		txtSearch.setColumns(10);
		
		JButton btnShowAll = new JButton("Show All");
		btnShowAll.setBounds(470, 426, 91, 26);
		frameCustomerRecordForm.getContentPane().add(btnShowAll);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(329, 112, 91, 26);
		frameCustomerRecordForm.getContentPane().add(btnCancel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Searching", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(12, 407, 295, 59);
		frameCustomerRecordForm.getContentPane().add(panel);
		
		JButton btnBack = new JButton("Exit");
		btnBack.setBounds(371, 426, 91, 26);
		frameCustomerRecordForm.getContentPane().add(btnBack);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Create New Customer ", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(12, 10, 549, 184);
		frameCustomerRecordForm.getContentPane().add(panel_1);
	}
}
