package forms;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Window.Type;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

import config.DBConfig;
import entities.Employee;
import entities.Theatre;
import services.TheatreService;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

public class TheatreForm {

	public JFrame frameTheatreRecordForm;
	private JTextField txtName;
	private JTable tblTheatre;
	private TheatreService theatreService;
	private final DBConfig dbConfig = new DBConfig();
	private JTextField textSeat;
	private DefaultTableModel dtm = new DefaultTableModel();
	private Theatre theatre;
	private List<Theatre> theatreList = new ArrayList<>();
	private List<Theatre> filterTheatreList = new ArrayList();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TheatreForm window = new TheatreForm();
					window.frameTheatreRecordForm.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * 
	 * @throws SQLException
	 */
	public TheatreForm() {
		initialize();
		this.initializeDependency();
		this.setTableDesign();
		this.loadAllTheatre(Optional.empty());
	}

	private void initializeDependency() {
		this.theatreService = new TheatreService();
	}

	private void setTableDesign() {
		dtm.addColumn("ID");
		dtm.addColumn("Theatre Name");
		dtm.addColumn("Total Seat");
		this.tblTheatre.setModel(dtm);
	}

	private void loadAllTheatre(Optional<List<Theatre>> optionalTheatre) {

		this.dtm = (DefaultTableModel) this.tblTheatre.getModel();
		this.dtm.getDataVector().removeAllElements();
		this.dtm.fireTableDataChanged();

		this.theatreList = this.theatreService.findAllTheatre();

		this.filterTheatreList = optionalTheatre.orElseGet(() -> this.theatreList).stream()
				.collect(Collectors.toList());

		filterTheatreList.forEach(e -> {
			Object[] row = new Object[3];
			row[0] = e.getTheatre_id();
			row[1] = e.getTheatre_name();
			row[2] = e.getTotal_seat();
			dtm.addRow(row);
		});

		this.tblTheatre.setModel(dtm);
	}

	private void resetFormData() {
		txtName.setText("");
		textSeat.setText("");

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frameTheatreRecordForm = new JFrame();
		frameTheatreRecordForm.getContentPane().setBackground(SystemColor.inactiveCaptionBorder);
		frameTheatreRecordForm.setTitle("Theatre Record Form");
		frameTheatreRecordForm.setBounds(100, 100, 497, 376);
		frameTheatreRecordForm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frameTheatreRecordForm.getContentPane().setLayout(null);

		JLabel lblName = new JLabel("Name");
		lblName.setHorizontalAlignment(SwingConstants.LEFT);
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblName.setBounds(62, 26, 85, 29);
		frameTheatreRecordForm.getContentPane().add(lblName);

		txtName = new JTextField();
		txtName.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtName.setColumns(10);
		txtName.setBounds(147, 26, 193, 29);
		frameTheatreRecordForm.getContentPane().add(txtName);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(46, 143, 399, 153);
		frameTheatreRecordForm.getContentPane().add(scrollPane);

		JLabel lblSeat = new JLabel("Total Seat");
		lblSeat.setHorizontalAlignment(SwingConstants.LEFT);
		lblSeat.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblSeat.setBounds(62, 65, 85, 29);
		frameTheatreRecordForm.getContentPane().add(lblSeat);

		textSeat = new JTextField();
		textSeat.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textSeat.setColumns(10);
		textSeat.setBounds(147, 65, 97, 29);
		frameTheatreRecordForm.getContentPane().add(textSeat);
		
		tblTheatre = new JTable();
		tblTheatre.setFont(new Font("Tahoma", Font.PLAIN, 15));
		scrollPane.setViewportView(tblTheatre);
		
		JButton btnSave = new JButton("Create");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 if (null != theatre && theatre.getTheatre_id() != 0) {
					 theatre.setTheatre_name(txtName.getText());
						theatre.setTotal_seat(textSeat.getText());

						if (!theatre.getTheatre_name().isBlank() && !theatre.getTotal_seat().equals(0)) {

							theatreService.updateTheatre(String.valueOf(theatre.getTheatre_id()), theatre);
							JOptionPane.showMessageDialog(null, "Update Successfully!!!");
							resetFormData();
							loadAllTheatre(Optional.empty());
							theatre = null;
							btnSave.setText("Create");
						}
				 }else {
					 Theatre theatreModel = new Theatre();
						theatreModel.setTheatre_name(txtName.getText());
						theatreModel.setTotal_seat(textSeat.getText());

						if (!theatreModel.getTheatre_name().isBlank() && !theatreModel.getTotal_seat().isBlank()) {

							theatreService.createTheatre(theatreModel);
							JOptionPane.showMessageDialog(null, "Save Successfully!!!");
							resetFormData();
							loadAllTheatre(Optional.empty());

						
						 } else { JOptionPane.showMessageDialog(null, "Enter Required Field");
						 }
				 }
			}
		});
		btnSave.setBounds(62, 102, 85, 29);
		frameTheatreRecordForm.getContentPane().add(btnSave);
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(157, 102, 85, 29);
		frameTheatreRecordForm.getContentPane().add(btnCancel);
		  btnCancel.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		resetFormData();
	        		theatre=null;
	        		btnSave.setText("Create");
	        	}
	        });
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Create Theatre", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(46, 10, 399, 129);
		frameTheatreRecordForm.getContentPane().add(panel);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(380, 306, 69, 21);
		frameTheatreRecordForm.getContentPane().add(btnExit);
		this.tblTheatre.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {

			if (!tblTheatre.getSelectionModel().isSelectionEmpty()) {
				String id = tblTheatre.getValueAt(tblTheatre.getSelectedRow(), 0).toString();

				theatre = theatreService.findTheatreById(id);
				// System.out.println(employee);

				txtName.setText(theatre.getTheatre_name());
				textSeat.setText(theatre.getTotal_seat());
				btnSave.setText("Edit");

			}
		});
	}
}
