module cinema {
	requires java.sql;
	requires java.desktop;
}