package shared.mapper;

import java.sql.ResultSet;
import java.sql.Time;
import java.sql.Timestamp;

import entities.*;


public class Mapper {

    public Employee mapToEmployee(Employee employee, ResultSet rs) {
        try {
            employee.setId(rs.getInt("emp_id"));
            employee.setName(rs.getString("emp_name"));
            employee.setPhone(rs.getString("emp_phone"));
            employee.setEmail(rs.getString("emp_email"));
            employee.setAddress(rs.getString("emp_address"));
            employee.setUsername(rs.getString("username"));
            employee.setActive(rs.getBoolean("active"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return employee;
    }
    
    public Theatre mapToTheatre(Theatre theatre, ResultSet rs) {
        try {
        	theatre.setTheatre_id(rs.getInt("theatre_id"));
        	theatre.setTheatre_name(rs.getString("theatre_name"));
        	theatre.setTotal_seat(rs.getString("total_seat"));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return theatre;
    }
    
    public Customer mapToCustomer(Customer customer, ResultSet rs) {
		try {
			customer.setCustomer_id(rs.getInt("customer_id"));
			customer.setCustomer_name(rs.getString("customer_name"));
			customer.setCustomer_phone(rs.getString("customer_phone"));
			customer.setCustomer_email(rs.getString("customer_email"));
			customer.setCustomer_address(rs.getString("customer_address"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return customer;
	}
    
    public Section mapToSection(Section section, ResultSet rs) {
        try {
        	section.setSection_id(rs.getInt("section_id"));
        	section.setStart_time(rs.getString("start_time"));
        	section.setEnd_time(rs.getString("end_time"));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return section;
    }
}
