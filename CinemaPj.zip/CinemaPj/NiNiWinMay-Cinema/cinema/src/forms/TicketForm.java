package forms;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JRadioButton;

public class TicketForm {

	private JFrame frame;
	private JTable tblTicket;
	private JTextField txtSearch;
	DefaultTableModel dtm=new DefaultTableModel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TicketForm window = new TicketForm();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TicketForm() {
		initialize();
		setTableDesign();
	}


	private void setTableDesign() {
		dtm.addColumn("Ticket No.");
		dtm.addColumn("Movie Name");
		dtm.addColumn("Theatre Name");
		dtm.addColumn("Seat No.");
		dtm.addColumn("Start Date");
		dtm.addColumn("End Date");
		dtm.addColumn("Start Time");
		dtm.addColumn("End Time");
		dtm.addColumn("Date");
		dtm.addColumn("Status");
		this.tblTicket.setModel(dtm);
	}
	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 700, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(15, 70, 657, 306);
		frame.getContentPane().add(scrollPane);
		
		tblTicket = new JTable();
		scrollPane.setViewportView(tblTicket);
		
		txtSearch = new JTextField();
		txtSearch.setBounds(52, 24, 118, 32);
		frame.getContentPane().add(txtSearch);
		txtSearch.setColumns(10);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.setBounds(194, 29, 91, 21);
		frame.getContentPane().add(btnSearch);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Searching", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(12, 0, 299, 68);
		frame.getContentPane().add(panel);
		
		JButton btnCreate = new JButton("New Ticket");
		btnCreate.setBounds(569, 41, 103, 21);
		frame.getContentPane().add(btnCreate);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(581, 380, 91, 21);
		frame.getContentPane().add(btnExit);
		
		JRadioButton rdbDelete = new JRadioButton("Delete");
		rdbDelete.setBounds(337, 35, 67, 21);
		frame.getContentPane().add(rdbDelete);
		
		JRadioButton rdbEdit = new JRadioButton("Edit");
		rdbEdit.setBounds(419, 35, 67, 21);
		frame.getContentPane().add(rdbEdit);
	}
}
