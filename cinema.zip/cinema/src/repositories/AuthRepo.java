package repositories;

public interface AuthRepo {
}
