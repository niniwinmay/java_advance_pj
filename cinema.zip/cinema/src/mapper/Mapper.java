package mapper;

import java.sql.ResultSet;

import entities.*;


public class Mapper {
	 public Actor mapToActor(Actor actor, ResultSet rs) {
	        try {
	        	actor.setActor_id(rs.getInt("actor_id"));
	        	actor.setActor_name(rs.getString("actor_name"));
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return actor;
	 }
	 
	 public Actress mapToActress(Actress actress, ResultSet rs) {
	        try {
	        	actress.setActress_id(rs.getInt("actress_id"));
	        	actress.setActress_name(rs.getString("actress_name"));
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return actress;
	 }
	 
	 public Director mapToDirector(Director director, ResultSet rs) {
	        try {
	        	director.setDirector_id(rs.getInt("director_id"));
	        	director.setDirector_name(rs.getString("director_name"));
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return director;
	 }
	 
	 public MovieType mapToMovieType(MovieType movieType, ResultSet rs) {
	        try {
	        	movieType.setMovieType_id(rs.getInt("movie_type_id"));
	        	movieType.setMovieType_name(rs.getString("movie_type_name"));
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        return movieType;
	 }
}
