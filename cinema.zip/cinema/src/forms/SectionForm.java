package forms;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;

import entities.Section;
import services.SectionService;

import javax.swing.JScrollPane;
import javax.swing.JTable;

public class SectionForm {

	private JFrame frame;
	private JTextField txtSTime;
	private JTextField txtEtime;
	private JTable tblSection;
	private SectionService sectionService;
	private DefaultTableModel dtm = new DefaultTableModel();
	private List<Section> sectionList = new ArrayList<>();
	private List<Section> filteredSectionList = new ArrayList<>();
	private Section section;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SectionForm window = new SectionForm();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	private void setTableDesign() {
		dtm.addColumn("ID");
		dtm.addColumn("Start Time");
		dtm.addColumn("End Time");
		this.tblSection.setModel(dtm);
	}
	

	public SectionForm() {
		initialize();
		setTableDesign();
	    sectionService=new SectionService();
		uploadData(Optional.empty());
	}


	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Start Time");
		lblNewLabel.setFont(new Font("Myanmar Text", Font.BOLD, 13));
		lblNewLabel.setBounds(39, 38, 71, 25);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblEndTime = new JLabel("End Time");
		lblEndTime.setFont(new Font("Myanmar Text", Font.BOLD, 13));
		lblEndTime.setBounds(39, 73, 71, 25);
		frame.getContentPane().add(lblEndTime);
		
		txtSTime = new JTextField();
		txtSTime.setToolTipText("(Sample Format : 10:30)");
		txtSTime.setBounds(120, 38, 108, 25);
		frame.getContentPane().add(txtSTime);
		txtSTime.setColumns(10);
		
		txtEtime = new JTextField();
		txtEtime.setToolTipText("(Sample Format : 10:30)");
		txtEtime.setColumns(10);
		txtEtime.setBounds(120, 73, 108, 25);
		frame.getContentPane().add(txtEtime);
		
		JButton btnSave = new JButton("Save");
		btnSave.setBounds(240, 53, 83, 21);
		frame.getContentPane().add(btnSave);
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			     if (null != section && section.getSection_id() != 0) {

			    	 section.setStart_time(txtSTime.getText());
			    	 section.setEnd_time(txtEtime.getText());

	                    if (!section.getStart_time().isBlank() || !section.getEnd_time().isBlank()) {

	                        sectionService.updateSection(String.valueOf(section.getStart_time()), section);
	                        resetformdata();
	                        section=null;
	                        uploadData(Optional.empty());
	                        btnSave.setText("Create");
	                    } else {
	                        JOptionPane.showMessageDialog(null, "Check Required Field");
	                    }
	                } else {
	                	if (txtSTime.getText().matches(".*[aA-zZ].*") || txtEtime.getText().matches(".*[aA-zZ].*")) {
	    					JOptionPane.showMessageDialog(null, "Time format must be hr:min");
	    				} else {
	                	
	                	Section section = new Section();
						section.setStart_time(txtSTime.getText());
				    	section.setEnd_time(txtEtime.getText());
				    	//System.out.println(section.getEnd_time());
	    				if (!section.getStart_time().isBlank() || !section.getEnd_time().isBlank()) {
	    						
	    						sectionService.createSection(section);
	    						uploadData(Optional.empty());
	    						resetformdata();
	    				} else {
	    					JOptionPane.showMessageDialog(null, "Enter RequiredField");
	    				}
	    				}
	                }
			}
		});
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBounds(328, 53, 83, 21);
		frame.getContentPane().add(btnCancel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Create section", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(12, 10, 410, 99);
		frame.getContentPane().add(panel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(12, 122, 229, 129);
		frame.getContentPane().add(scrollPane);
		
		tblSection = new JTable();
		scrollPane.setViewportView(tblSection);
		this.tblSection.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
			if (!tblSection.getSelectionModel().isSelectionEmpty()) {

				String id = tblSection.getValueAt(tblSection.getSelectedRow(), 0).toString();

				section = sectionService.findSectionById(id);

				txtSTime.setText(section.getStart_time());
				txtEtime.setText(section.getEnd_time());
				btnSave.setText("Edit");
			}
		});
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(320, 218, 91, 21);
		frame.getContentPane().add(btnExit);
	}
	
	public void resetformdata() {
		txtSTime.setText("");
        txtEtime.setText("");
	}
	 
	private void uploadData(Optional<List<Section>> optionalSection) {

		 this.dtm = (DefaultTableModel) this.tblSection.getModel();
		 this.dtm.getDataVector().removeAllElements();
		 this.dtm.fireTableDataChanged();

		this.sectionList = this.sectionService.findAllSection();
		this.filteredSectionList = optionalSection.orElseGet(() ->
									this.sectionList).stream()
									.collect(Collectors.toList());

		filteredSectionList.forEach(e -> {
			Object[] row = new Object[3];
			row[0] = e.getSection_id();
			row[1] = e.getStart_time();
			row[2] = e.getEnd_time();
			dtm.addRow(row);
		});

		this.tblSection.setModel(dtm);
		//System.out.println(filteredSectionList);
	}
}
