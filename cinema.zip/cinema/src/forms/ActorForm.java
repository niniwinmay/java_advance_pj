package forms;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.table.DefaultTableModel;
import entities.Actor;
import services.ActorService;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import java.awt.Color;
import javax.swing.UIManager;

public class ActorForm {

	JFrame frame;
	private JTextField txtName;
	private JTable tblActor;
	private ActorService actorService;
	private DefaultTableModel dtm = new DefaultTableModel();
	private List<Actor> actorList = new ArrayList<>();
	private List<Actor> filteredActorList = new ArrayList<>();
	private Actor actor;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ActorForm window = new ActorForm();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	public ActorForm() {
		initialize();
		this.actorService=new ActorService();
		setTableDesign();
		uploadData(Optional.empty());
		
	}

	private void setTableDesign() {
		dtm.addColumn("ID");
		dtm.addColumn("Name");
		this.tblActor.setModel(dtm);
	}
	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Actor Name");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(23, 34, 107, 31);
		frame.getContentPane().add(lblNewLabel);
		
		txtName = new JTextField();
		txtName.setBounds(131, 39, 107, 24);
		frame.getContentPane().add(txtName);
		txtName.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 102, 326, 148);
		frame.getContentPane().add(scrollPane);
		
		
		
		JButton btnSave = new JButton("Create");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			     if (null != actor && actor.getActor_id() != 0) {

			    	 	actor.setActor_name(txtName.getText());

	                    if (!actor.getActor_name().isBlank()) {

	                        actorService.updateActor(String.valueOf(actor.getActor_id()), actor);
	                        txtName.setText("");
	                        actor=null;
	                        uploadData(Optional.empty());
	                        btnSave.setText("Create");
	                    } else {
	                        JOptionPane.showMessageDialog(null, "Check Required Field");
	                    }
	                } else {
	                	if (txtName.getText().matches(".*[0-9].*")) {
	    					JOptionPane.showMessageDialog(null, "Name must be String");
	    				} else if (!txtName.getText().isBlank()) {

	    					Actor actor = new Actor();
	    					actor.setActor_name(txtName.getText());
	    					actorService.createActor(actor);
	    					uploadData(Optional.empty());
	    					txtName.setText("");
	    				} else {
	    					JOptionPane.showMessageDialog(null, "Enter RequiredField");
	    				}
	                }
			}
		});
		btnSave.setBounds(248, 40, 74, 23);
		frame.getContentPane().add(btnSave);
		
		tblActor = new JTable();
		tblActor.setBackground(UIManager.getColor("CheckBox.background"));
		scrollPane.setViewportView(tblActor);
		
		JButton btnNewButton = new JButton("Cancel");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				actor=null;
				txtName.setText("");
				btnSave.setText("Create");
			}
		});
		btnNewButton.setBounds(248, 68, 74, 23);
		frame.getContentPane().add(btnNewButton);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Create New Actor", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(10, 11, 326, 90);
		frame.getContentPane().add(panel);
		this.tblActor.getSelectionModel().addListSelectionListener((ListSelectionEvent e) -> {
			if (!tblActor.getSelectionModel().isSelectionEmpty()) {

				String id = tblActor.getValueAt(tblActor.getSelectedRow(), 0).toString();

				actor = actorService.findActorById(id);

				txtName.setText(actor.getActor_name());
				btnSave.setText("Edit");
			}
		});
	}


	private void uploadData(Optional<List<Actor>> optionalActor) {

		 this.dtm = (DefaultTableModel) this.tblActor.getModel();
		 this.dtm.getDataVector().removeAllElements();
		 this.dtm.fireTableDataChanged();

		this.actorList = this.actorService.findAllActor();
		this.filteredActorList = optionalActor.orElseGet(() ->
									this.actorList).stream()
									.collect(Collectors.toList());

		filteredActorList.forEach(e -> {
			Object[] row = new Object[2];
			row[0] = e.getActor_id();
			row[1] = e.getActor_name();
			dtm.addRow(row);
		});

		this.tblActor.setModel(dtm);
	}
}
